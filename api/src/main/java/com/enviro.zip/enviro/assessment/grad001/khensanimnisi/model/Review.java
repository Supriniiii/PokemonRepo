package com.enviro.assessment.grad001.khensanimnisi.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

@Entity

public class Review {
    public Review(int id, String title, String content, int start) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.star = star;
    }

    public Review() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String title;
    private String content;
    private int star;

    public Review(int id, String title, String content, int start, Pokemon pokemon) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.star = start;
        this.pokemon = pokemon;
    }

    @ManyToOne(fetch = FetchType.LAZY)//saves space, load relationship when you need it, doent load the entire object
    @JoinColumn(name = "pokemon_id")

    private Pokemon pokemon;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public Pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }
}
