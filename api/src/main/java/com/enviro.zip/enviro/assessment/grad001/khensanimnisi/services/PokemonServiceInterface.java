package com.enviro.assessment.grad001.khensanimnisi.services;


import com.enviro.assessment.grad001.khensanimnisi.DTO.PokemonDTO;
import org.springframework.stereotype.Service;

import java.util.List;

//helps us use the repository methods by creating, create, get, getAll, delete,update

public interface PokemonServiceInterface {
    PokemonDTO CreatePokemon(PokemonDTO pokemonDTO);
    List<PokemonDTO>getAll();
    PokemonDTO getPokemonByID(int id);
    PokemonDTO updatePokemon(PokemonDTO pokemonDTO,int id );
    void deletePokemon(int id);

}
