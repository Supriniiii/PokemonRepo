package com.enviro.assessment.grad001.khensanimnisi.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.Date;

//helps handle exceptions
//this class will handle all exceptions thrown
@ControllerAdvice

public class GlobalExceptionHandler {
    //interceptor the exceptions
    @ExceptionHandler(com.enviro.assessment.grad001.khensanimnisi.exceptions.PokemonNotFoundException.class)
    public ResponseEntity<ErrorObject> handlePokemonNotFound(com.enviro.assessment.grad001.khensanimnisi.exceptions.PokemonNotFoundException ex, WebRequest request) {
        //the object is what could have been displayed in the web page of the error
        ErrorObject errorObject=new ErrorObject();
        errorObject.setMessage(ex.getMessage());
        errorObject.setStatusCode(HttpStatus.NOT_FOUND.value());
        errorObject.setTimestamp(new Date());
        return new ResponseEntity<ErrorObject>(errorObject,HttpStatus.NOT_FOUND);
    }
}
