package com.enviro.assessment.grad001.khensanimnisi.controllers;


import com.enviro.assessment.grad001.khensanimnisi.DTO.PokemonDTO;
import com.enviro.assessment.grad001.khensanimnisi.services.impl.PokemonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/")
public class PokemonController   {
    //retrieving the service to use  it the controller
    private  PokemonService pokemonService;
    @Autowired
    public PokemonController(PokemonService pokemonService) {
        this.pokemonService = pokemonService;
    }

    @GetMapping("pokemon/getAll")
    public ResponseEntity<List<PokemonDTO>>getPokemon(){
return new ResponseEntity<>(pokemonService.getAll(),HttpStatus.OK);

    }

   @GetMapping("pokemon/{id}")
    public ResponseEntity<PokemonDTO> pokemonDetail(@PathVariable int id){
    return ResponseEntity.ok(pokemonService.getPokemonByID(id));

//        return new Pokemon(id, "Polite", "Water");
    }

//creating the pokemon through the service and storing in the database
    @PostMapping("pokemon/create")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<PokemonDTO> createdPokemon(@RequestBody PokemonDTO pokemonDTO) {
//        System.out.println(pokemon.getName());
//        System.out.println(pokemon.getType());
       // pokemonService.CreatePokemon(pokemonDTO);


    return  new ResponseEntity<>(pokemonService.CreatePokemon(pokemonDTO),HttpStatus.CREATED);
    }
    @PutMapping("pokemon/{id}/update")
    public ResponseEntity<PokemonDTO>updatePokemon(@RequestBody PokemonDTO pokemonDTO,@PathVariable Integer id){
        PokemonDTO response=pokemonService.updatePokemon(pokemonDTO,id);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
    @DeleteMapping("pokemon/{id}/delete")
    public ResponseEntity<String>deletePokemon(@PathVariable Integer id){
        pokemonService.deletePokemon(id);
        return new ResponseEntity<>("Pokemon deleted",HttpStatus.OK);

    }


}
