package com.enviro.assessment.grad001.khensanimnisi.Repository;


import com.enviro.assessment.grad001.khensanimnisi.model.Pokemon;
import org.springframework.data.jpa.repository.JpaRepository;
//CONNECTS TO DATABASE THAT ACTUALLY FINDALL,, FINDBYIDsaveall,deletebyid, fetone, getbyid
public interface PokemonRepository extends JpaRepository<Pokemon,Integer> {


}
