package com.enviro.assessment.grad001.khensanimnisi.services.impl;

import com.enviro.assessment.grad001.khensanimnisi.DTO.PokemonDTO;
import com.enviro.assessment.grad001.khensanimnisi.Repository.PokemonRepository;
import com.enviro.assessment.grad001.khensanimnisi.exceptions.PokemonNotFoundException;
import com.enviro.assessment.grad001.khensanimnisi.model.Pokemon;
import com.enviro.assessment.grad001.khensanimnisi.services.PokemonServiceInterface;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.stream.Collectors;

//helps us use the repository methods by creating, create, get, getAll, delete,update
@Service
public class PokemonService implements PokemonServiceInterface {
 //@Autowired brings the repository methods into the service through the its interface, but best way to do that is to just call the repository

    private PokemonRepository pokemonRepository;
    @Autowired
    public PokemonService(PokemonRepository pokemonRepository) {
        this.pokemonRepository = pokemonRepository;
    }

    @Override
    public PokemonDTO CreatePokemon(PokemonDTO pokemonDTO) {
        //creating the object to the server
        Pokemon pokemon=new Pokemon();
        pokemon.setName(pokemonDTO.getName());
        pokemon.setType(pokemonDTO.getType());
//using the repository ,we are sending it to the database
        pokemonRepository.save(pokemon);

        PokemonDTO pokemonResponse=new PokemonDTO();
        pokemonResponse.setId(pokemon.getId());
        pokemonResponse.setName(pokemonDTO.getName());
        pokemonResponse.setType(pokemonDTO.getType());
        return pokemonResponse;
    }




    @Override
    public List<PokemonDTO> getAll() {
        //  Pokemon pokemon3=pokemonRepository.findById(333).orElseThrow(()->new PokemonNotFoundException("pokemon could not be found"));





    //    Pageable pageable= PageRequest.of(pageNumber,pageSize);

        //Page<Pokemon>pokemons=pokemonRepository.findAll();
       List< Pokemon> pokemon=pokemonRepository.findAll();
      // List<Pokemon>listOfPokemon=pokemon.getContent();
       //pokemon stream is like forEach that returns a list, we are mapping the pokemon to its DTO AND RETURNING A LIST USING COLLECTORS
       //map returns a new list
        return pokemon.stream().map(p->mapToDTO(p)).collect(Collectors.toList());

    }

    @Override
    public PokemonDTO getPokemonByID(int id) {
        Pokemon pokemon =pokemonRepository.findById(id).orElseThrow(()-> new PokemonNotFoundException("Pokemon is not found"));
        return mapToDTO(pokemon);
    }

    @Override
    public PokemonDTO updatePokemon(PokemonDTO pokemonDTO, int id) {
        Pokemon pokemon=pokemonRepository.findById(id).orElseThrow(()->new PokemonNotFoundException("Pokemon is not found"));
        pokemon.setName(pokemonDTO.getName());
        pokemon.setType(pokemonDTO.getType());
        Pokemon updatedPokemon =pokemonRepository.save(pokemon);
        return mapToDTO(pokemon);
    }

    @Override
    public void deletePokemon(int id) {
        Pokemon pokemon=pokemonRepository.findById(id).orElseThrow(()->new PokemonNotFoundException("pokemon could not be deleted"));
        pokemonRepository.delete(pokemon);

    }

    public PokemonDTO mapToDTO(Pokemon pokemon){
        PokemonDTO pokemonDTO=new PokemonDTO();
        pokemonDTO.setId(pokemon.getId());
        pokemonDTO.setName(pokemon.getName());
        pokemonDTO.setType(pokemon.getType());
        return  pokemonDTO;

    }
    public  Pokemon mapToEntity(PokemonDTO pokemonDTO){
        Pokemon pokemon=new Pokemon();
        pokemon.setId(pokemonDTO.getId());
        pokemon.setName(pokemon.getName());
        pokemon.setType(pokemon.getType());
        return pokemon;

    }
}
